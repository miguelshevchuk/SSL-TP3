

int noEstaEnLaTabla(char *s);

void agregarALaTabla(char *nuevoID);
